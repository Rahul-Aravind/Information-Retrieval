
public class StopWords {

	public static String[] stopWordList = { "a", "all", "an", "and", "any", "ar", "are", "as", "at", "be", "been", "but", "by",
			"few", "for", "have", "he", "her", "here", "him", "his", "how", "i", "in", "is", "it", "its", "many", "me",
			"my", "none", "of", "on", "or", "our", "she", "some", "to", "the", "their", "them", "there", "they", "that",
			"this", "us", "was", "what", "when", "where", "which", "who", "why", "will", "with", "you", "your" };

	public static void main(String args[]) {
		System.out.println(stopWordList.length);
	}
}
